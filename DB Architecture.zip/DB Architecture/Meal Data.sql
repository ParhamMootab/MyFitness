INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Spinach & Mushroom Quiche", 277, "https://www.eatingwell.com/recipe/278023/spinach-mushroom-quiche/", 
"This healthy vegetarian quiche recipe is as simple as it gets. It's a quiche without the fussy crust! It's filled with
 sweet wild mushrooms and savory Gruyère cheese. Enjoy it for breakfast or brunch, or serve it with a light salad for lunch."); 
 
 INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Spicy Weight-Loss Cabbage Soup", 167, "https://www.eatingwell.com/recipe/256474/mexican-cabbage-soup/", 
"Based on a popular weight-loss plan, this healthy cabbage soup recipe gets tons of flavor and a
 metabolism-boosting kick from spicy chiles."); 
 
  INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Veggie & Hummus Sandwich", 325, "https://www.eatingwell.com/recipe/259817/veggie-hummus-sandwich/", 
"This mile-high vegetable and hummus sandwich makes the perfect heart-healthy vegetarian lunch to go.
 Mix it up with different flavors of hummus and different types of vegetables depending on your mood."); 
 
 
   INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Roast Chicken & Sweet Potatoes", 408, "https://www.eatingwell.com/recipe/250549/roast-chicken-sweet-potatoes/", 
"Caramelized sweet potatoes and red onion are the bed for chicken thighs that cook up fast in a very hot oven--perfect for 
a quick healthy chicken dinner. Serve with a fall salad of mixed greens, sliced apples and blue cheese."); 
 
 
    INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Zucchini Noodles with Avocado Pesto & Shrimp", 446 , "https://www.eatingwell.com/recipe/257004/zucchini-noodles-with-avocado-pesto-shrimp/", 
"Cut some carbs and use spiralized zucchini in place of noodles in this zesty pesto pasta dish recipe.
 Top with Cajun-seasoned shrimp to complete this quick and easy dinner."); 
 
 
 INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Slow-Cooker Braised Beef with Carrots & Turnips", 318, "https://www.eatingwell.com/recipe/256499/slow-cooker-braised-beef-with-carrots-turnips/", 
"The spice blend in this healthy beef stew recipe--cinnamon, allspice and cloves
--may conjure images of apple pie, but the combo is a great fit in savory applications too.
 Serve over creamy polenta or buttered whole-wheat egg noodles.");
 
 
 INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Spinach & Egg Sweet Potato Toast", 124 , "https://www.eatingwell.com/recipe/262099/spinach-egg-sweet-potato-toast/", 
"Skip the gluten and get some vitamin C with this healthy sweet potato toast recipe. 
Topped with spinach, egg and a dash of hot sauce, it's a delicious alternative to eggs Benedict.");
 
  INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Chicken Cutlets with Sun-Dried Tomato Cream Sauce", 324, "https://www.eatingwell.com/recipe/276341/chicken-cutlets-with-sun-dried-tomato-cream-sauce/", 
"Though a chicken cutlet may be a chicken breast cut in half, this recipe shows how to make chicken cutlets 
with double the deliciousness. A jar of sun-dried tomatoes does double duty for this healthy dinner recipe.
 The flavorful oil they're packed in is used to sauté the chicken, and the tomatoes go into the cream sauce.");
 
 
  INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Blueberry-Lemon Ricotta Pound Cake", 303, "https://www.eatingwell.com/recipe/251419/blueberry-lemon-ricotta-pound-cake/", 
"This healthy pound cake recipe isn't just delicious--it also only requires one bowl to make. For the best cake texture, 
be sure to beat the sugar and butter together long enough in Step 2 to look creamy--the time it
 takes to get there varies according to the type of electric mixer you have. Serve with brunch or alongside a cup of coffee in the afternoon.");
 
   INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Chocolate-Peanut Butter Energy Bars", 203, "https://www.eatingwell.com/recipe/266632/chocolate-peanut-butter-energy-bars/", 
"Dates provide all the sweetness you need for these no-bake energy bars. Each square serves up a hearty dose of protein--thanks
 to peanut butter and peanuts--as well as fiber from rolled oats. Kids will love the chewy bites with crunchy nuts.");
 
 
  INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Sriracha-Buffalo Cauliflower Bites", 99 , "https://www.eatingwell.com/recipe/251316/sriracha-buffalo-cauliflower-bites/", 
"This recipe for spicy Buffalo cauliflower bites is a great vegetarian alternative to Buffalo wings. Roasted cauliflower stands in for chicken
 and provides more fiber and fewer calories. Serve this easy appetizer with carrot sticks, celery and your favorite ranch or blue cheese dressing.");
 
 
   INSERT INTO meal(meal_name, calorie, meal_recipe, Meal_Desc) VALUES
("Peanut Butter-Banana Cinnamon Toast", 266, "https://www.eatingwell.com/recipe/261628/peanut-butter-banana-cinnamon-toast/", 
"This satisfying peanut butter-banana toast gets a sprinkle of cinnamon for an extra flavor boost.");
 
 
 