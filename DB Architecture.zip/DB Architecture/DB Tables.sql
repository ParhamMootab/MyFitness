DROP DATABASE IF EXISTS MyFitness;

CREATE DATABASE MyFitness;
USE MyFitness;

CREATE TABLE User (
	userId int auto_increment,
    email varchar(50),
    password varchar(200),
    PRIMARY KEY (userId)
);

CREATE TABLE Diet (
	dietId int auto_increment,
    date varchar(50),
    time varchar(50),
    diet_Name varchar(50),
    PRIMARY KEY (dietId)
);

CREATE TABLE Diet_User (
	dietId int,
    userId int,
    PRIMARY KEY (userId),
    FOREIGN KEY (dietId) REFERENCES Diet(dietId)
    ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (userId) REFERENCES User(userId)
    ON UPDATE CASCADE ON DELETE CASCADE

);

CREATE TABLE Meal (
	mealId int auto_increment,
    meal_Desc text,
    meal_recipe varchar(100),
    calorie int,
    meal_Name varchar(50),
    PRIMARY KEY (mealId)
);


CREATE TABLE Diet_Meal (
	dietId int,
    mealId int,
    PRIMARY KEY (dietId),
    FOREIGN KEY (dietId) REFERENCES Diet(dietId)
    ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (mealId) REFERENCES Meal(mealId)
    ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE Workout (
	workoutId int auto_increment,
    workout_Name varchar(50),
    PRIMARY KEY (workoutId)
);

CREATE TABLE workout_User (
	workoutId int,
    userId int,
    PRIMARY KEY (userId),
    FOREIGN KEY (workoutId) REFERENCES Workout(workoutId)
    ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (userId) REFERENCES User(userId)
    ON UPDATE CASCADE ON DELETE CASCADE 
);

CREATE TABLE Exercise (
	exerciseId int auto_increment,
    name varchar(100),
    instruction text,
    muscle varchar(50),
    picture varchar(120),
    PRIMARY KEY (exerciseId)
);


CREATE TABLE workout_Exercise (
	workoutId int,
    exerciseId int,
    rep int,
    PRIMARY KEY (workoutId),
    FOREIGN KEY (workoutId) REFERENCES Workout(workoutId)
    ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (exerciseId) REFERENCES Exercise(exerciseId)
    ON UPDATE CASCADE ON DELETE CASCADE
);







